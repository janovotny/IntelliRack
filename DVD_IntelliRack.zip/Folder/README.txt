Hier sind alle Dokumente zum Projekt.
Die Ordner haben ein Prefix im Namen (e.g. 01_, 02_, ...)
Das Prefix stellt die Registernummer der Ausgedrukten version dar.
Der Spezialfall 00_ beschreibt alle Dokumente die vor den Register abgelegt werden (e.g. Titelblatt).